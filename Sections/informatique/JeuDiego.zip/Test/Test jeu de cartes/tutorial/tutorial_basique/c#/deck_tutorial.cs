
int nombreTotalCartes = 0;
List<Card> deck = new List<Card>
{
    // (5) Familier
    new Card
    {
        Id = 1,
        Name = "Chien errant",
        Type = "Familier",
        Attack = 2,
        Health = 1,
        ManaCost = 1,
        Keyword = "Aucun",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chien_errant.png"
    },
    new Card
    {
        Id = 2,
        Name = "Chaton Enchanté",
        Type = "Familier",
        Attack = 1,
        Health = 1,
        ManaCost = 1,
        Keyword = "Aucun",
        Effect = "Arrivé : reduit le cout 1 un sort dans la main",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 3,
        Name = "Serpent des Ombres",
        Type = "Familier",
        Attack = 1,
        Health = 2,
        ManaCost = 2,
        Keyword = "Vénin",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/serpent_des_ombres.png"
    },
    new Card
    {
        Id = 4,
        Name = "Chien de garde",
        Type = "Familier",
        Attack = 2,
        Health = 3,
        ManaCost = 3,
        Keyword = "Aucun",
        Effect = "Arrivé : obtient le mot-clef \"Gardien\" si il y a au moins 2 créatures de type \"Humain\" sur le plateau",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chien_de_garde.png"
    },
    new Card
    {
        Id = 5,
        Name = "Cheval de guerre",
        Type = "Familier",
        Attack = 3,
        Health = 5,
        ManaCost = 5,
        Keyword = "Rapide",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/cheval_de_guerre.png"
    },

    // (12) Humain
    new Card
    {
        Id = 6,
        Name = "Paysan",
        Type = "Humain",
        Attack = 1,
        Health = 1,
        ManaCost = 1,
        Keyword = "Aucun",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/paysant.png"
    },
    new Card
    {
        Id = 7,
        Name = "Danseur des Lames",
        Type = "Humain",
        Attack = 1,
        Health = 1,
        ManaCost = 1,
        Keyword = "aucun",
        Effect = "Arrivé : inflige 1 de dégat à un ennemi",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/Danseur_des_Lames.png"
    },
    new Card
    {
        Id = 8,
        Name = "Assassin stagiaire",
        Type = "Humain",
        Attack = 1,
        Health = 1,
        ManaCost = 2,
        Keyword = "Vénin",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/Assassin_stagiaire.png"
    },
    new Card
    {
        Id = 9,
        Name = "Soldat",
        Type = "Humain",
        Attack = 2,
        Health = 2,
        ManaCost = 2,
        Keyword = "Aucun",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 10,
        Name = "Mage de feu",
        Type = "Humain",
        Attack = 2,
        Health = 2,
        ManaCost = 3,
        Keyword = "Aucun",
        Effect = "Arrivé : inflige 2 points de dégat à un ennemi",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 11,
        Name = "Archer agile",
        Type = "Humain",
        Attack = 3,
        Health = 1,
        ManaCost = 2,
        Keyword = "Aucun",
        Effect = "Arrivé : met dans ta main une magie \"Flèche\"",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 12,
        Name = "Magesse d'eau",
        Type = "Humain",
        Attack = 2,
        Health = 2,
        ManaCost = 3,
        Keyword = "Aucun",
        Effect = "Arrivé : soigne 2 points de vie à un allié",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 13,
        Name = "Dresseur de chien",
        Type = "Humain",
        Attack = 1,
        Health = 3,
        ManaCost = 3,
        Keyword = "Aucun",
        Effect = "Continu : Les créatures de type 'Familier' ont +1 d'attaque",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 14,
        Name = "Druide",
        Type = "Humain",
        Attack = 2,
        Health = 2,
        ManaCost = 3,
        Keyword = "Aucun",
        Effect = "Arrivé : invoque 2 \"chien érrant\" sur le plateau de jeu",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 15,
        Name = "Guérisseur Éthéré",
        Type = "Humain",
        Attack = 2,
        Health = 2,
        ManaCost = 3,
        Keyword = "Soin = 3",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 16,
        Name = "General",
        Type = "Humain",
        Attack = 3,
        Health = 3,
        ManaCost = 4,
        Keyword = "Aucun",
        Effect = "Continu : Les créatures de type 'Humain' ont +1 d'attaque",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 17,
        Name = "Chevalier robuste",
        Type = "Humain",
        Attack = 4,
        Health = 6,
        ManaCost = 7,
        Keyword = "Armure, Rapide = 1",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },

    // (4) Structrure
    new Card
    {
        Id = 18,
        Name = "Tour de garde",
        Type = "Structrure",
        Attack = 2,
        Health = 3,
        ManaCost = 3,
        Keyword = "Armure",
        Effect = "Aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 19,
        Name = "Gardien de pierre",
        Type = "Structrure",
        Attack = 3,
        Health = 4,
        ManaCost = 3,
        Keyword = "Armure = 1",
        Effect = "aucun",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 20,
        Name = "Forge du forgeron",
        Type = "Structrure",
        Attack = 0,
        Health = 3,
        ManaCost = 3,
        Keyword = "Aucun",
        Effect = "Continu : Au debut de chaque tour, donne +1 d'attaque et +1 de point de vie à un allie aléatoire",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 21,
        Name = "Caserne",
        Type = "Structrure",
        Attack = 0,
        Health = 5,
        ManaCost = 5,
        Keyword = "Aucun",
        Effect = "Continu : Au debut de chaque tour, invoque un \"Soldat\" (2, 2, 2)",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },

    // (6) Sort
    new Card
    {
        Id = 22,
        Name = "Flèche",
        Type = "Sort",
        ManaCost = 1,
        Effect = "1 point de dégat à un ennemi",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 23,
        Name = "Boule de feu",
        Type = "Sort",
        ManaCost = 2,
        Effect = "2 points de dégat à un ennemi",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 24,
        Name = "Renforcement d'Armure",
        Type = "Sort",
        ManaCost = 2,
        Effect = "+1 point d'attaque, +1 point de vie, +'Armure = 1' à une créature allié",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 25,
        Name = "Hymne de guérison",
        Type = "Sort",
        ManaCost = 3,
        Effect = "Soigne 2 points de vie à tous les alliès",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 26,
        Name = "Étreinte de la Nature",
        Type = "Sort",
        ManaCost = 4,
        Effect = "2 points de dégat à un ennemi et pioche 2 cartes",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    },
    new Card
    {
        Id = 27,
        Name = "Blizzard",
        Type = "Sort",
        ManaCost = 6,
        Effect = "3 points de dégats à tous les ennemis",
        ImagePath = "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"
    }
};