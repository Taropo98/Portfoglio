
// Import the necessary libraries for event handling and UI manipulation
using System;
using System.Collections.Generic;
using System.Windows.Forms;

// Define a class to hold the card information
public class Card
{
    public string Nom { get; set; }
    public string Type { get; set; }
    public int Attaque { get; set; }
    public int Vie { get; set; }
    public int CoutMana { get; set; }
    public string Motclef { get; set; }
    public string Effet { get; set; }
}

public class Program
{
    private static List<Card> deck = new List<Card>();
    private static int nombreTotalCartes;
    private static int MAX = 0;
    private static Card carteSelectionne;

    public static void Main()
    {
        // Add event handlers for the card placement buttons
        Button emplacementA2 = new Button();
        emplacementA2.Click += EmplacementA2_Click;

        Button emplacementA3 = new Button();
        emplacementA3.Click += EmplacementA3_Click;

        Button emplacementA4 = new Button();
        emplacementA4.Click += EmplacementA4_Click;

        Button emplacementA5 = new Button();
        emplacementA5.Click += EmplacementA5_Click;

        Button emplacementJ1 = new Button();
        emplacementJ1.Click += EmplacementJ1_Click;

        Button emplacementJ2 = new Button();
        emplacementJ2.Click += EmplacementJ2_Click;

        Button emplacementJ3 = new Button();
        emplacementJ3.Click += EmplacementJ3_Click;

        Button emplacementJ4 = new Button();
        emplacementJ4.Click += EmplacementJ4_Click;

        Button emplacementJ5 = new Button();
        emplacementJ5.Click += EmplacementJ5_Click;

        // Calculate the remaining number of cards
        int nombreCartesRestantes = nombreTotalCartes + deck.Count;
        Console.WriteLine("Nombre de cartes restantes dans le deck : " + nombreCartesRestantes);

        // Add event handler for the draw card button
        Button drawCardButton = new Button();
        drawCardButton.Text = "-deck";
        drawCardButton.Click += DrawCard_Click;

        // Run the application
        Application.Run();
    }

    private static void EmplacementA2_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement A2 sélectionné");
    }

    private static void EmplacementA3_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement A3 sélectionné");
    }

    private static void EmplacementA4_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement A4 sélectionné");
    }

    private static void EmplacementA5_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement A5 sélectionné");
    }

    private static void EmplacementJ1_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement J1 sélectionné");
    }

    private static void EmplacementJ2_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement J2 sélectionné");
    }

    private static void EmplacementJ3_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement J3 sélectionné");
    }

    private static void EmplacementJ4_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement J4 sélectionné");
    }

    private static void EmplacementJ5_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement J5 sélectionné");
    }

    private static void DrawCard_Click(object sender, EventArgs e)
    {
        if (MAX != 9)
        {
            if (deck.Count > 0)
            {
                Random random = new Random();
                int indexAleatoire = random.Next(deck.Count);

                // Remove a random card from the deck
                Card carteEnlevee = deck[indexAleatoire];
                deck.RemoveAt(indexAleatoire);
                Console.WriteLine("Carte enlevée du deck et ajouté à la main: " + carteEnlevee.Nom);
                MessageBox.Show("Vous avez pioché: " + '"' + carteEnlevee.Nom + '"');

                // Create a new button to represent the drawn card
                Button carteMain = new Button();
                carteMain.Text = $"<i>{carteEnlevee.Nom}</i>";
                carteMain.Click += CarteMain_Click;

                // Add the card button to the player's hand
                FlowLayoutPanel main_du_joueur = new FlowLayoutPanel();
                main_du_joueur.Controls.Add(carteMain);

                MAX++;
            }
            else
            {
                MessageBox.Show("Votre deck est vide");
                Console.WriteLine("Impossible de pioché: Deck vide");
            }
        }
        else
        {
            MessageBox.Show("Vous avez trop de cartes en main");
            Console.WriteLine("Impossible de pioché: Trop de carte en main");
        }
    }

    private static void CarteMain_Click(object sender, EventArgs e)
    {
        Button carteButton = (Button)sender;
        string carteNom = carteButton.Text.Trim('<', 'i', '>');
        Card carte = deck.Find(c => c.Nom == carteNom);

        if (carte != null)
        {
            Console.WriteLine("La carte sélectionée est: " + '"' + carte.Nom + '"');
            string message = $"\"{carte.Nom}\"\nType: \"{carte.Type}\"\nAttaque: \"{carte.Attaque}\"\nVie \"{carte.Vie}\"\ncoutMana: \"{carte.CoutMana}\"\nMotclef: \"{carte.Motclef}\"\nEffet: \"{carte.Effet}\"";
            MessageBox.Show(message);
            carteSelectionne = carte;
            Console.WriteLine(carteSelectionne.Nom);

            // Add event handlers for the card placement buttons when a card is selected
            Button emplacementA1 = new Button();
            emplacementA1.Click += EmplacementA1_Click;
        }
    }

    private static void EmplacementA1_Click(object sender, EventArgs e)
    {
        Console.WriteLine("Emplacement A1 sélectionné");
    }
}

