console.log("J1 " + EmplacementJ1);
console.log("A1 " + EmplacementA1);
if (A1 == 1 && carte_non_double == 1 /*&& Repet == 0*/){
emplacementJ1.addEventListener("click", function() {
    //Repet = 1;
    event.stopPropagation();
        emplacementA1.addEventListener("click", function() {
            if (A2 == 1){
            J1_attaque_A1();
            console.log(A3);
            A3++;
        }
    });
});
}/*else{
    if (A2 == 1 && carte_non_double == 1 && Repet == 0){
    emplacementA1.addEventListener("click", function() {
        alert(`"${EmplacementA1.nom}"\nType: "${EmplacementA1.Type}"\nAttaque: "${EmplacementA1.attaque}"\nVie "${EmplacementA1.vie}"\ncoutMana: "${EmplacementA1.coutMana}"\nMotclef: "${EmplacementA1.Motclef}"\nEffet: "${EmplacementA1.Effet}"`);
    });
    }
    }*/