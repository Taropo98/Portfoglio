nombreTotalCartes = 0;
window.deck = [
	
        //(5) Familier
		{ id: 1, nom: 'Chien errant', Type: 'Familier', attaque: 2, vie: 10, coutMana: 1, Motclef: 'Aucun', Effet: 'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/tutorial/tutorial_basique/css/images_carte/chien_errant.png"},
		{ id: 1, nom: 'Chaton Enchanté', Type: 'Familier', attaque: 1, vie: 1, coutMana: 1, Motclef: 'Aucun', Effet :'Arrivé : reduit le cout 1 un sort dans la main', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'Serpent des Ombres', Type: 'Familier', attaque: 1, vie: 2, coutMana: 2, Motclef: 'Vénin', Effet :'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/serpent_des_ombres.png"},
		/*{ id: 1, nom: 'Chien de garde', Type: 'Familier', attaque: 2, vie: 3, coutMana: 3, Motclef: 'Aucun', Effet :'Arrivé : obtient le mot-clef "Gardien" si il y a au moins 2 créatures de type "Humain" sur le plateau', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chien_de_garde.png" },
		{ id: 1, nom: 'Cheval de guerre', Type: 'Familier', attaque: 3, vie: 5, coutMana: 5, Motclef: 'Rapide', Effet :'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/cheval_de_guerre.png" },
		
		//(12) Humain
		{ id: 1, nom: 'Paysan', Type: 'Humain', attaque: 1, vie: 1, coutMana: 1, Motclef: 'Aucun', Effet: 'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/paysant.png" },
		{ id: 1, nom: 'Danseur des Lames', Type: 'Humain', attaque: 1, vie: 1, coutMana: 1, Motclef: 'aucun', Effet: 'Arrivé : inflige 1 de dégat à un ennemi', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/Danseur_des_Lames.png" },
		{ id: 1, nom: 'Assassin stagiaire', Type: 'Humain', attaque: 1, vie: 1, coutMana: 2, Motclef: 'Vénin', Effet: 'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/Assassin_stagiaire.png" },
		{ id: 1, nom: 'Soldat', Type: 'Humain', attaque: 2, vie: 2, coutMana: 2, Motclef: 'Aucun', Effet: 'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'Mage de feu', Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Aucun', Effet: 'Arrivé : inflige 2 points de dégat à un ennemi', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'Archer agile', Type: 'Humain', attaque: 3, vie: 1, coutMana: 2, Motclef: 'Aucun', Effet: 'Arrivé : met dans ta main une magie "Flèche"', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: "Magesse d'eau", Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Aucun', Effet: 'Arrivé : soigne 2 points de vie à un allié', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'Dresseur de chien', Type: 'Humain', attaque: 1, vie: 3, coutMana: 3, Motclef: 'Aucun', Effet: "Continu : Les créatures de type 'Familier' ont +1 d'attaque", image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'Druide', Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Aucun', Effet: 'Arrivé : invoque 2 "chien érrant" sur le plateau de jeu', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'Guérisseur Éthéré', Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Soin = 3', Effet: 'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'General', Type: 'Humain', attaque: 3, vie: 3, coutMana: 4, Motclef: 'Aucun', Effet: "Continu : Les créatures de type 'Humain' ont +1 d'attaque", image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		{ id: 1, nom: 'Chevalier robuste', Type: 'Humain', attaque: 4, vie: 6, coutMana: 7, Motclef: 'Armure, Rapide = 1', Effet: 'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png" },
		
		//(4) Structrure
		{ id: 2, nom: 'Tour de garde', Type: 'Structrure', attaque: 2, vie: 3, coutMana: 3, Motclef: 'Armure', Effet :'Aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		{ id: 2, nom: 'Gardien de pierre', Type: 'Structrure', attaque: 3, vie: 4, coutMana: 3, Motclef: 'Armure = 1', Effet :'aucun', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
        { id: 2, nom: 'Forge du forgeron', Type: 'Structrure', attaque: 0, vie: 3, coutMana: 3, Motclef: 'Aucun', Effet :"Continu : Au debut de chaque tour, donne +1 d'attaque et +1 de point de vie à un allie aléatoire", image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		{ id: 2, nom: 'Caserne', Type: 'Structrure', attaque: 0, vie: 5, coutMana: 5, Motclef: 'Aucun', Effet :'Continu : Au debut de chaque tour, invoque un "Soldat" (2, 2, 2)', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		
		//(6) Sort
		{ id: 3, nom: 'Flèche', Type: 'Sort', coutMana: 1, Effet :'1 point de dégat à un ennemi', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		{ id: 3, nom: 'Boule de feu', Type: 'Sort', coutMana: 2, Effet :'2 points de dégat à un ennemi', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		{ id: 3, nom: "Renforcement d'Armure", Type: 'Sort', coutMana: 2, Effet :"+1 point d'attaque, +1 point de vie, +'Armure = 1' à une créature allié", image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		{ id: 3, nom: 'Hymne de guérison', Type: 'Sort', coutMana: 3, Effet :'Soigne 2 points de vie à tous les alliès', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		{ id: 3, nom: 'Étreinte de la Nature', Type: 'Sort', coutMana: 4, Effet :'2 points de dégat à un ennemi et pioche 2 cartes', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},
		{ id: 3, nom: 'Blizzard', Type: 'Sort', coutMana: 6, Effet :'3 points de dégats à tous les ennemis', image: "C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/js/images_carte/chaton_enchanté.png"},*/
	
    ];