function desactiver_Fin_de_tour() {
    document.getElementById("-deck").disabled = true;
}
function activer_Fin_de_tour() {
    document.getElementById("-deck").disabled = false
}
function ajout_mana() {
    Mana = Mana + 2;
    console.log("Il y a " + Mana + " de mana.")
}
function cout_carte_mana() {
    Mana = Mana - carteSelectionne.coutMana;
    console.log("Le mana enlevé est de " + carteSelectionne.coutMana + " donc il reste " + Mana + " de mana.")
}

function J1_attaque_A1(){
    console.log("La vie A1: " + EmplacementA1.vie);
    console.log("L'attaque J1: " + EmplacementJ1.attaque);
    EmplacementA1.vie = EmplacementA1.vie - EmplacementJ1.attaque
    console.log("La vie restante A1: " + EmplacementA1.vie);
    if(EmplacementA1.vie <= 0){
        alert("Morte")
    }else{
    document.getElementById('emplacementA1').innerHTML = '"' + EmplacementA1.nom + '"' +'<br>' + 'Vie: ' + EmplacementA1.vie + '<br>' +'Attaque: ' + EmplacementA1.attaque;
}
}