let Mana = 100;
let A1 = 0;
let A2 = 0;
let A3 = 0;
let A4 = 0;
let A5 = 0;
let A6 = 0;
let Repet = 0;
let Anti_bug = 0;
let carte_non_double = 0;

let EmplacementJ1;
let EmplacementA1;

let Image_carte = new Image();
let ManaJ = document.getElementById("Mana_emplacement");

const nombreCartesRestantes = nombreTotalCartes + deck.length;
console.log("Nombre de cartes restantes dans le deck : " + nombreCartesRestantes);

document.addEventListener('DOMContentLoaded', function () {
    const deck_joueur = document.getElementById('deck_joueur');
    const deckJoueur = window.deck;
    alert("Nombre de cartes restantes dans le deck : " + nombreCartesRestantes);
});

let MAX = 0;
let carteSelectionne;
const main_du_joueur = document.getElementById('main_joueur');

document.getElementById("-deck").addEventListener("click", function() {
    ajout_mana();
    ManaJ.innerHTML = Mana + " de mana";
    if(main_du_joueur.childElementCount !== 9) {
        if(deck.length > 0) {
            const indexAleatoire = Math.floor(Math.random() * deck.length);
        
            //Récupère la carte correspondant à l'index aléatoire
            let carteEnlevee = deck.splice(indexAleatoire, 1)[0];
            console.log("Carte enlevée du deck et ajouté à la main:", carteEnlevee.nom);
            alert("Vous avez pioché: " + '"'+ carteEnlevee.nom +'"');
            
            let carteMain = carteEnlevee;
            carteMain = document.createElement('div');
            carteMain.classList.add('carte_main');
            main_du_joueur.appendChild(carteMain);
            carteMain.innerHTML = `<p><i>${carteEnlevee.nom}</i></p>`;
            carteMain.addEventListener("click", function() {
                if(Anti_bug == 0) {
                desactiver_Fin_de_tour();
                console.log("La carte sélectionée est: " + '"' + carteEnlevee.nom + '"');
                alert(`"${carteEnlevee.nom}"\nType: "${carteEnlevee.Type}"\nAttaque: "${carteEnlevee.attaque}"\nVie "${carteEnlevee.vie}"\ncoutMana: "${carteEnlevee.coutMana}"\nMotclef: "${carteEnlevee.Motclef}"\nEffet: "${carteEnlevee.Effet}"`);
                carteSelectionne = carteEnlevee;
                console.log(carteMain);
                carte_non_double = 0;
                Anti_bug = 1;
                }
    
                if(A1 == 0){
                    document.getElementById("emplacementJ1").addEventListener("click", function() {
                            if(carte_non_double == 0){
                            EmplacementJ1 = document.getElementById('emplacementJ1');
                            if(carteSelectionne.id == 3){
                                alert("Cette carte est un sort donc impossible de la placer");
                                //console.log("Cette carte est un sort donc impossible de la placer");
                                activer_Fin_de_tour();
                            } else {
                            if(carteSelectionne.id == 2){
                                alert("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                console.log("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                activer_Fin_de_tour();
                            } else {                               
                            if(carteSelectionne.coutMana > Mana){
                                alert("Pas assez de mana");
                                activer_Fin_de_tour();
                            } else {
                            console.log("Emplacement J1 sélectionné avec la carte " + '"' + carteSelectionne.nom);
                            EmplacementJ1 = carteSelectionne;
                            
                            /*Image_carte.src = carteSelectionne.image;
                            console.log(Image_carte);
                            Image_carte.style.width = '130px';
                            Image_carte.style.height = '120px';*/
                            document.getElementById('emplacementJ1').innerHTML = /*'<img src="' + Image_carte + '" alt="Image de la carte">' + '<br>' +*/ '"' + carteSelectionne.nom + '"' +'<br>' + 'Vie: ' + carteSelectionne.vie + '<br>' +'Attaque: ' + carteSelectionne.attaque;
                            main_du_joueur.removeChild(carteMain);
                            console.log(EmplacementJ1);
                            A1++;
                            carte_non_double = 1;
                            Anti_bug = 0;
                            cout_carte_mana();
                            activer_Fin_de_tour();
                            ManaJ.innerHTML = Mana + " de mana";
                            if (A1 == 1 || A2 == 1 || A3 == 1 || A4 == 1 || A5 == 1 || A6 == 1) {
                                // Crée un élément <script>
                                let scriptElement = document.createElement('script');

                                localStorage.setItem('emplacementJ1', EmplacementJ1, A1, carte_non_double, A3, Repet);

                                // Définit le chemin de ton fichier JavaScript
                                scriptElement.src = 'js/tutoriel_basique_suite.js';
                                scriptElement.defer = true;

                                // Ajoute le script à la fin du corps du document (ou à un autre endroit selon tes besoins)
                                document.body.appendChild(scriptElement);

                            }
                        }
                    }
                    }
                        }       
                    });
                    }


                    if(A2 == 0){
                        document.getElementById("emplacementA1").addEventListener("click", function() {
                                if(carte_non_double == 0){
                                EmplacementA1 = document.getElementById('emplacementA1');
                                if(carteSelectionne.id == 3){
                                    alert("Cette carte est un sort donc impossible de la placer");
                                    //console.log("Cette carte est un sort donc impossible de la placer");
                                    activer_Fin_de_tour();
                                } else {
                                if(carteSelectionne.id == 2){
                                    alert("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                    console.log("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                    activer_Fin_de_tour();
                                } else {                               
                                if(carteSelectionne.coutMana > Mana){
                                    alert("Pas assez de mana");
                                    activer_Fin_de_tour();
                                } else {
                                console.log("Emplacement A1 sélectionné avec la carte " + '"' + carteSelectionne.nom);
                                EmplacementA1 = carteSelectionne;
                                
                                /*Image_carte.src = carteSelectionne.image;
                                console.log(Image_carte);
                                Image_carte.style.width = '130px';
                                Image_carte.style.height = '120px';*/
                                document.getElementById('emplacementA1').innerHTML = /*'<img src="' + Image_carte + '" alt="Image de la carte">' + '<br>' +*/ '"' + carteSelectionne.nom + '"' +'<br>' + 'Vie: ' + carteSelectionne.vie + '<br>' +'Attaque: ' + carteSelectionne.attaque;
                                main_du_joueur.removeChild(carteMain);
                                console.log(EmplacementA1);
                                A2++;
                                carte_non_double = 1;
                                Anti_bug = 0;
                                cout_carte_mana();
                                activer_Fin_de_tour();
                                ManaJ.innerHTML = Mana + " de mana";
                                if (A1 == 1 || A2 == 1 || A3 == 1 || A4 == 1 || A5 == 1 || A6 == 1) {
                                    // Crée un élément <script>
                                    let scriptElement = document.createElement('script');
    
                                    localStorage.setItem('emplacementA1', EmplacementA1, A2, carte_non_double, A3, Repet);
    
                                    // Définit le chemin de ton fichier JavaScript
                                    scriptElement.src = 'js/tutoriel_basique_suite.js';
                                    scriptElement.defer = true;
    
                                    // Ajoute le script à la fin du corps du document (ou à un autre endroit selon tes besoins)
                                    document.body.appendChild(scriptElement);
    
                                }
                            }
                        }
                        }
                            }       
                        });
                        }

                    
                    
                    /*if(A2 == 0){
                    document.getElementById("emplacementJ2").addEventListener("click", function() {
                            if(carte_non_double == 0){
                            let EmplacementJ2 = document.getElementById('emplacementJ2');
                            if(carteSelectionne.id == 3){
                                alert("Cette carte est un sort donc impossible de la placer");
                                console.log("Cette carte est un sort donc impossible de la placer");
                                activer_Fin_de_tour();
                            } else {
                            if(carteSelectionne.id == 2){
                                alert("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                console.log("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                activer_Fin_de_tour();
                            } else {
                                if(carteSelectionne.coutMana > Mana){
                                    alert("Pas assez de mana");
                                    activer_Fin_de_tour();
                                } else {
                            console.log("Emplacement J2 sélectionné avec la carte " + '"' + carteSelectionne.nom);
                            EmplacementJ2 = carteSelectionne;
                            document.getElementById('emplacementJ2').innerHTML = '"' + carteSelectionne.nom + '"' +'<br>' + 'Vie: ' + carteSelectionne.vie + '<br>' +'Attaque: ' + carteSelectionne.attaque;
                            main_du_joueur.removeChild(carteMain);
                            console.log(EmplacementJ2);
                            A2++;
                            carte_non_double = 1;
                            Anti_bug = 0;
                            cout_carte_mana();
                            activer_Fin_de_tour();
                            ManaJ.innerHTML = Mana + " de mana";
                            if (A1 == 1 || A2 == 1 || A3 == 1 || A4 == 1 || A5 == 1 || A6 == 1) {
                                // Crée un élément <script>
                                let scriptElement = document.createElement('script');

                                localStorage.setItem('emplacementJ2', EmplacementJ2, A1, carte_non_double, A3, Repet, A2);

                                // Définit le chemin de ton fichier JavaScript
                                scriptElement.src = 'js/tutoriel_basique_suite.js';
                                scriptElement.defer = true;

                                // Ajoute le script à la fin du corps du document (ou à un autre endroit selon tes besoins)
                                document.body.appendChild(scriptElement);

                            }
                            }
                        }
                    }      
                }   
                    });
                    }
                    
                    if(A3 == 0){
                    document.getElementById("emplacementJ3").addEventListener("click", function() {
                            if(carte_non_double == 0){
                            let EmplacementJ3 = document.getElementById('emplacementJ3');
                            if(carteSelectionne.id == 3){
                                alert("Cette carte est un sort donc impossible de la placer");
                                console.log("Cette carte est un sort donc impossible de la placer");
                                activer_Fin_de_tour();
                            } else {
                            if(carteSelectionne.id == 2){
                                alert("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                console.log("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                activer_Fin_de_tour();
                            } else {
                                if(carteSelectionne.coutMana > Mana){
                                    alert("Pas assez de mana");
                                    activer_Fin_de_tour();
                                } else {
                            console.log("Emplacement J3 sélectionné avec la carte " + '"' + carteSelectionne.nom);
                            EmplacementJ3 = carteSelectionne;
                            document.getElementById('emplacementJ3').innerHTML = '"' + carteSelectionne.nom + '"' +'<br>' + 'Vie: ' + carteSelectionne.vie + '<br>' +'Attaque: ' + carteSelectionne.attaque;
                            main_du_joueur.removeChild(carteMain);
                            console.log(EmplacementJ3);
                            A3++;
                            carte_non_double = 1;
                            Anti_bug = 0;
                            cout_carte_mana();
                            activer_Fin_de_tour();
                            ManaJ.innerHTML = Mana + " de mana";
                            }
                        }
                    }
                }
            });
                    }
                    if(A4 == 0){
                    document.getElementById("emplacementJ4").addEventListener("click", function() {
                            if(carte_non_double == 0){
                            let EmplacementJ4 = document.getElementById('emplacementJ4');
                            if(carteSelectionne.id == 3){
                                alert("Cette carte est un sort donc impossible de la placer");
                                console.log("Cette carte est un sort donc impossible de la placer");
                                activer_Fin_de_tour();
                            } else {
                            if(carteSelectionne.id == 2){
                                alert("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                console.log("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                activer_Fin_de_tour();
                            } else {                               
                            if(carteSelectionne.coutMana > Mana){
                                alert("Pas assez de mana");
                                activer_Fin_de_tour();
                            } else {
                            console.log("Emplacement J4 sélectionné avec la carte " + '"' + carteSelectionne.nom);
                            EmplacementJ4 = carteSelectionne;
                            document.getElementById('emplacementJ4').innerHTML = '"' + carteSelectionne.nom + '"' +'<br>' + 'Vie: ' + carteSelectionne.vie + '<br>' +'Attaque: ' + carteSelectionne.attaque;
                            main_du_joueur.removeChild(carteMain);
                            console.log(EmplacementJ4);
                            A4++;
                            carte_non_double = 1;
                            Anti_bug = 0;
                            cout_carte_mana();
                            activer_Fin_de_tour();
                            ManaJ.innerHTML = Mana + " de mana";
                        }
                    }
                        }       
                    }   
                });
                    }
                    if(A5 == 0){
                    document.getElementById("emplacementJ5").addEventListener("click", function() {
                            if(carte_non_double == 0){
                            let EmplacementJ5 = document.getElementById('emplacementJ5');
                            if(carteSelectionne.id == 3){
                                alert("Cette carte est un sort donc impossible de la placer");
                                console.log("Cette carte est un sort donc impossible de la placer");
                                activer_Fin_de_tour();
                            } else {
                            if(carteSelectionne.id == 2){
                                alert("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                console.log("Cette carte est un batiment donc impossible de la placer sur ce terrain");
                                activer_Fin_de_tour();
                            } else {                               
                            if(carteSelectionne.coutMana > Mana){
                                alert("Pas assez de mana");
                                activer_Fin_de_tour();
                            } else {
                            console.log("Emplacement J5 sélectionné avec la carte " + '"' + carteSelectionne.nom);
                            EmplacementJ5 = carteSelectionne;
                            document.getElementById('emplacementJ5').innerHTML = '"' + carteSelectionne.nom + '"' +'<br>' + 'Vie: ' + carteSelectionne.vie + '<br>' +'Attaque: ' + carteSelectionne.attaque;
                            main_du_joueur.removeChild(carteMain);
                            console.log(EmplacementJ5);
                            A5++;
                            carte_non_double = 1;
                            Anti_bug = 0;
                            cout_carte_mana();
                            activer_Fin_de_tour();
                            ManaJ.innerHTML = Mana + " de mana";
                        }
                    }
                        }       
                    }   
                });
                    }
                    if(A6 == 0){
                    document.getElementById("emplacementSJ6").addEventListener("click", function() {
                            if(carte_non_double == 0){
                            let EmplacementSJ6 = document.getElementById('emplacementSJ6');
                            if(carteSelectionne.id == 3){
                                alert("Cette carte est un sort donc impossible de la placer");
                                console.log("Cette carte est un sort donc impossible de la placer");
                                activer_Fin_de_tour();
                            } else {
                            if(carteSelectionne.id == 1){
                                alert("Cette carte est une créature donc impossible de la placer sur ce terrain");
                                console.log("Cette carte est une créature donc impossible de la placer sur ce terrain");
                                activer_Fin_de_tour();
                            } else {                               
                            if(carteSelectionne.coutMana > Mana){
                                alert("Pas assez de mana");
                                activer_Fin_de_tour();
                            } else {
                            console.log("Emplacement SJ6 sélectionné avec la carte " + '"' + carteSelectionne.nom);
                            EmplacementSJ6 = carteSelectionne;
                            document.getElementById('emplacementSJ6').innerHTML = '"' + carteSelectionne.nom + '"' +'<br>' + 'Type: ' + carteSelectionne.Type + '<br>' + 'Vie: ' + carteSelectionne.vie + '<br>' +'Attaque: ' + carteSelectionne.attaque;
                            main_du_joueur.removeChild(carteMain);
                            console.log(EmplacementSJ6);
                            A6++;
                            carte_non_double = 1;
                            Anti_bug = 0;
                            cout_carte_mana();
                            activer_Fin_de_tour();
                            ManaJ.innerHTML = Mana + " de mana";
                        }
                    }
                        }       
                    }   
                });
                    }*/
                });
        }else{
            alert("Votre deck est vide");
            console.log("Impossible de pioché: Deck vide");
        }
    }else{
        alert("Vous avez trop de cartes en main");
        console.log("Impossible de pioché: Trop de carte en main");
    }
});