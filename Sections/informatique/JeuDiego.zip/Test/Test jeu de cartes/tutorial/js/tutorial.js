var dialogueTutorial
document.getElementById('suivant').addEventListener('click', function() {
	dialogueTutorial = document.getElementById('dialogue-tutorial');
	dialogueTutorial.style.float = 'left';
	dialogueTutorial.style.justifyContent = 'center';
	dialogueTutorial.style.width = '400px';
    dialogueTutorial.style.margin = '50px';
    dialogueTutorial.style.padding = '20px';
    dialogueTutorial.style.border = '2px solid #ccc';
    dialogueTutorial.style.borderRadius = '10px';
    dialogueTutorial.style.backgroundColor = '#f8f8f8';
    dialogueTutorial.style.textAlign = 'center';
	document.getElementById('parler').innerHTML = "A droite de l'écran tu pourras choisir quelle type de tutoriel";
	document.getElementById('suivant').innerHTML = "Compris";
	boutton = document.getElementById('suivant')
	boutton.id = 'suivant1';
	tutorial_type.style.display="block";
	
document.getElementById('suivant1').addEventListener('click', function() {
        alert("Choisissez un tutoriel");
		});

document.getElementById('tutoriel_base').addEventListener('click', function() {
	window.location.href ="tutorial_basique/tutorial_base.html";
		});

document.getElementById('tutoriel_avance').addEventListener('click', function() {
	alert("Cette partie est encore en développement");
		});
});