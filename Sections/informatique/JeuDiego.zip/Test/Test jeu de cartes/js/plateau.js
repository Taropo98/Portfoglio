alert("Ici vous pourrez voir quel type de cartes seront présente dans ce jeu (pour l'instant)")

document.addEventListener('DOMContentLoaded', function () {
    const deck_presentation = document.getElementById('deck_presentation');

    const deck = [
	
        //(5) Familier
		{ id: 1, nom: 'Chien errant', Type: 'Familier', attaque: 2, vie: 1, coutMana: 1, Motclef: 'Aucun', Effet: 'Aucun', image: "js/images_carte/chien_errant.png"},
		{ id: 2, nom: 'Chaton Enchanté', Type: 'Familier', attaque: 1, vie: 1, coutMana: 1, Motclef: 'Aucun', Effet :'Arrivé : reduit le cout 1 un sort dans la main', image: "js/images_carte/chaton_enchanté.png" },
		{ id: 3, nom: 'Serpent des Ombres', Type: 'Familier', attaque: 1, vie: 2, coutMana: 2, Motclef: 'Vénin', Effet :'Aucun', image: "js/images_carte/serpent_des_ombres.png"},
		{ id: 4, nom: 'Chien de garde', Type: 'Familier', attaque: 2, vie: 3, coutMana: 3, Motclef: 'Aucun', Effet :'Arrivé : obtient le mot-clef "Gardien" si il y a au moins 2 créatures de type "Humain" sur le plateau', image: "js/images_carte/chien_de_garde.png" },
		{ id: 5, nom: 'Cheval de guerre', Type: 'Familier', attaque: 3, vie: 5, coutMana: 5, Motclef: 'Rapide', Effet :'Aucun', image: "js/images_carte/cheval_de_guerre.png" },
		
		//(12) Humain
		{ id: 6, nom: 'Paysan', Type: 'Humain', attaque: 1, vie: 1, coutMana: 1, Motclef: 'Aucun', Effet: 'Aucun', image: "js/images_carte/paysant.png" },
		{ id: 7, nom: 'Danseur des Lames', Type: 'Humain', attaque: 1, vie: 1, coutMana: 1, Motclef: 'aucun', Effet: 'Arrivé : inflige 1 de dégat à un ennemi', image: "js/images_carte/Danseur_des_Lames.png" },
		{ id: 8, nom: 'Assassin stagiaire', Type: 'Humain', attaque: 1, vie: 1, coutMana: 2, Motclef: 'Vénin', Effet: 'Aucun', image: "js/images_carte/Assassin_stagiaire.png" },
		{ id: 9, nom: 'Soldat', Type: 'Humain', attaque: 2, vie: 2, coutMana: 2, Motclef: 'Aucun', Effet: 'Aucun', image: "js/images_carte/chaton_enchanté.png" },
		{ id: 10, nom: 'Mage de feu', Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Aucun', Effet: 'Arrivé : inflige 2 points de dégat à un ennemi', image: "js/images_carte/chaton_enchanté.png" },
		{ id: 11, nom: 'Archer agile', Type: 'Humain', attaque: 3, vie: 1, coutMana: 2, Motclef: 'Aucun', Effet: 'Arrivé : met dans ta main une magie "Flèche"', image: "js/images_carte/chaton_enchanté.png" },
		{ id: 12, nom: "Magesse d'eau", Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Aucun', Effet: 'Arrivé : soigne 2 points de vie à un allié', image: "js/images_carte/chaton_enchanté.png" },
		{ id: 13, nom: 'Dresseur de chien', Type: 'Humain', attaque: 1, vie: 3, coutMana: 3, Motclef: 'Aucun', Effet: "Continu : Les créatures de type 'Familier' ont +1 d'attaque", image: "js/images_carte/chaton_enchanté.png" },
		{ id: 14, nom: 'Druide', Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Aucun', Effet: 'Arrivé : invoque 2 "chien érrant" sur le plateau de jeu', image: "js/images_carte/chaton_enchanté.png" },
		{ id: 15, nom: 'Guérisseur Éthéré', Type: 'Humain', attaque: 2, vie: 2, coutMana: 3, Motclef: 'Soin = 3', Effet: 'Aucun', image: "js/images_carte/chaton_enchanté.png" },
		{ id: 16, nom: 'General', Type: 'Humain', attaque: 3, vie: 3, coutMana: 4, Motclef: 'Aucun', Effet: "Continu : Les créatures de type 'Humain' ont +1 d'attaque", image: "js/images_carte/chaton_enchanté.png" },
		{ id: 17, nom: 'Chevalier robuste', Type: 'Humain', attaque: 4, vie: 6, coutMana: 7, Motclef: 'Armure, Rapide = 1', Effet: 'Aucun', image: "js/images_carte/chaton_enchanté.png" },
		
		//(4) Structrure
		{ id: 18, nom: 'Tour de garde', Type: 'Structrure', attaque: 2, vie: 3, coutMana: 3, Motclef: 'Armure', Effet :'Aucun', image: "js/images_carte/chaton_enchanté.png"},
		{ id: 19, nom: 'Gardien de pierre', Type: 'Structrure', attaque: 3, vie: 4, coutMana: 3, Motclef: 'Armure = 1', Effet :'aucun', image: "js/images_carte/chaton_enchanté.png"},
        { id: 20, nom: 'Forge du forgeron', Type: 'Structrure', attaque: 0, vie: 3, coutMana: 3, Motclef: 'Aucun', Effet :"Continu : Au debut de chaque tour, donne +1 d'attaque et +1 de point de vie à un allie aléatoire", image: "js/images_carte/chaton_enchanté.png"},
		{ id: 21, nom: 'Caserne', Type: 'Structrure', attaque: 0, vie: 5, coutMana: 5, Motclef: 'Aucun', Effet :'Continu : Au debut de chaque tour, invoque un "Soldat" (2, 2, 2)', image: "js/images_carte/chaton_enchanté.png"},
		
		//(6) Sort
		{ id: 22, nom: 'Flèche', Type: 'Sort', coutMana: 1, Effet :'1 point de dégat à un ennemi', image: "js/images_carte/chaton_enchanté.png"},
		{ id: 23, nom: 'Boule de feu', Type: 'Sort', coutMana: 2, Effet :'2 points de dégat à un ennemi', image: "js/images_carte/chaton_enchanté.png"},
		{ id: 24, nom: "Renforcement d'Armure", Type: 'Sort', coutMana: 2, Effet :"+1 point d'attaque, +1 point de vie, +'Armure = 1' à une créature allié", image: "js/images_carte/chaton_enchanté.png"},
		{ id: 25, nom: 'Hymne de guérison', Type: 'Sort', coutMana: 3, Effet :'Soigne 2 points de vie à tous les alliès', image: "js/images_carte/chaton_enchanté.png"},
		{ id: 26, nom: 'Étreinte de la Nature', Type: 'Sort', coutMana: 4, Effet :'2 points de dégat à un ennemi et pioche 2 cartes', image: "js/images_carte/chaton_enchanté.png"},
		{ id: 27, nom: 'Blizzard', Type: 'Sort', coutMana: 6, Effet :'3 points de dégats à tous les ennemis', image: "js/images_carte/chaton_enchanté.png"},
	
    ];

    // Génère les cartes sur le plateau
    deck.forEach((carte, index) => {
        const carteElement = document.createElement('div');
        carteElement.classList.add('carte');
        carteElement.innerHTML = (carte.Type === 'Sort') ?
		` 
			<p><i>${carte.nom}</i></p>
			<img src="${carte.image}" alt="${carte.nom}">
			<p><b>Type:</b> ${carte.Type}</p>
			<p><b>Coût de Mana:</b> ${carte.coutMana}</p>
			<p><b>Effet:</b> ${carte.Effet}</p>
		` :
		`
			<p><i>${carte.nom}</i></p>
			<img src="${carte.image}" alt="${carte.nom}">
			<p><b>Type:</b> ${carte.Type}</p>
			<p><b>Attaque:</b> ${carte.attaque}</p>
			<p><b>Vie:</b> ${carte.vie}</p>
			<p><b>Coût de Mana:</b> ${carte.coutMana}</p>
			<p><b>Mot-clef:</b> ${carte.Motclef}</p>
			<p><b>Effet:</b> ${carte.Effet}</p>
		`;

        // Ajoute un identifiant unique à chaque carte
        carteElement.id = `carte-${index + 1}`;

        // Ajoute la carte au plateau
        deck_presentation.appendChild(carteElement);


        carteElement.addEventListener('click', function() {
			alert(`Carte "${carte.nom}" cliquée !`);
			
				if(carte.Motclef.includes ('Armure')){			
					alert('Armure = X : Reduit les dégats subis de "X" points');
				}
				if(carte.Motclef.includes ('Vénin')){			
					alert('Vénin : Tue en un coup');
				}
				if(carte.Motclef.includes ('Rapide')){			
					alert('Rapide : Peut attaque directement');
				}
				if(carte.Motclef.includes ('Gardien')){			
					alert("Gardien : Obliger d'etre attaque en premier pour attaque les autres");
				}
				if(carte.Motclef.includes ('Soin')){			
					alert('Soin = x : Soigne une creature ou un joueur de "x" points');
				}
				if(carte.Effet.includes ('Continu')){			
					alert("Continu : Competence passive");
				}
				if(carte.Effet.includes ('Arrivé')){			
					alert("Arrivé : competence qui s'active à l'arrive sur le plateau");
				}
				if(carte.Effet.includes ('Mort')){			
					alert("Mort : Competence qui s'active à la mort");
				}
        });
    });
});
document.getElementById("Suivant").addEventListener("click", function() {
	window.location.href ='C:/Users/petri/Documents/Project_jeu/Test/Test jeu de cartes/tutorial/tutorial.html';
});