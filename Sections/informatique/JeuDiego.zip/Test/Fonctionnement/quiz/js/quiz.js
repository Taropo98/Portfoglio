alert("Bienvenue dans la tour des quiz")
alert("Il y aura quelques questions avec 4 réponse différentes mais une seule est juste")
document.getElementById("reponse1").addEventListener("click", function () {
	alert("bonne reponse")
	window.location.href = "C:/Users/petri/Documents/Project_jeu/Test/Fonctionnement/Jeu carte/Jeu_carte.html";
});
document.getElementById("reponse2").addEventListener("click", function () {
	alert("mauvaise reponse")
});
document.getElementById("reponse3").addEventListener("click", function () {
	alert("mauvaise reponse")
});
document.getElementById("reponse4").addEventListener("click", function () {
	alert("mauvaise reponse")
});