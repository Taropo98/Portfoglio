alert("Bienvenue dans la tour des cartes");
alert("Dans cette tour il y aura des ennemis à battre dans des combats de cartes");