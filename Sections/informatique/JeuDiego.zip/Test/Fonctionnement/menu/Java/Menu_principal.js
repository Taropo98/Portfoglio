document.getElementById("Start").addEventListener("click", function() {
  // Lorsque le bouton est cliqué, il disparait
  Start.style.opacity = "0";
  window.location.href = 'Fonctionnement/quiz/quiz.html';
});



/*document.getElementById('Chargement_video').classList.toggle('active');
let Chargement = document.getElementById('Chargement');
  document.getElementById('Chargement_video').classList.toggle('active');
  Chargement.style.display = 'block';
  Chargement.play();*/